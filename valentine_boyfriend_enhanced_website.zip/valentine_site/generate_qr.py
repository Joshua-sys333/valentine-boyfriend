# Run: python generate_qr.py "https://YOUR-USERNAME.github.io/valentine-boyfriend/"
import sys
try:
    import qrcode
except ImportError:
    raise SystemExit("Install the QR package first: pip install qrcode[pil]")
if len(sys.argv) != 2:
    raise SystemExit('Usage: python generate_qr.py "https://your-live-url.com/"')
url=sys.argv[1]
img=qrcode.make(url)
img.save("valentine_qr.png")
print("Saved valentine_qr.png for",url)
