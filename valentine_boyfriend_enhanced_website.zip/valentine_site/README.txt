VALENTINE BOYFRIEND WEBSITE — SETUP GUIDE

WHAT IS INSIDE
- index.html = the full interactive website
- jumpscare.png = the puppy photo used for the NO answer
- generate_qr.py = creates a QR code for your final live website URL

FASTEST WAY TO PUBLISH (GITHUB PAGES)
1. Go to https://github.com and sign in.
2. Click + > New repository.
3. Name it: valentine-boyfriend
4. Set it to Public.
5. Create the repository.
6. Upload BOTH index.html and jumpscare.png into the repository root.
7. Click Settings > Pages.
8. Under "Build and deployment", choose "Deploy from a branch".
9. Select branch "main" and folder "/ (root)". Save.
10. Wait a minute or two. GitHub will give you a URL similar to:
    https://YOUR-USERNAME.github.io/valentine-boyfriend/
11. Open that URL on your phone to test everything.

MAKE THE QR CODE
Option A — easiest: use an online QR generator and paste your final GitHub Pages URL.
Option B — use the included script:
    pip install qrcode[pil]
    python generate_qr.py "https://YOUR-USERNAME.github.io/valentine-boyfriend/"
It will create valentine_qr.png in the same folder.

CUSTOMISE HER NAME
Open index.html in a text editor and find:
    const HER_NAME = "";
Change it to something like:
    const HER_NAME = "Samantha";

CUSTOMISE WORDING
The questions and romantic message are normal HTML text, so you can edit them directly in index.html.

IMPORTANT
The website is intentionally self-contained except for jumpscare.png, which must stay beside index.html.
Do not put the image in a separate folder unless you also change src="jumpscare.png" in the HTML.
